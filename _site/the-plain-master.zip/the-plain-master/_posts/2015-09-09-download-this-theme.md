---
title: Download this Theme
updated: 2015-09-09 10:38
---

This is a minimalist Jekyll theme built to focus on writing stuffs that matter. Suitable to be used as a personal blog!

> **_Fork_** or **_download_** the theme [**here**](https://github.com/heiswayi/the-plain).
