---
layout: page
title: About
---

Hello.

The main purpose of this theme is to be as simple as it could be, so you can focus on writing your stuffs. This is your About page. You may describe about yourself here; who you are, what are you currently doing, share some of your projects, your social links and how people can contact you, etc.

**Just write thing that matters..**

Enjoy!
